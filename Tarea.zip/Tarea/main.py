from lists import GUI # En Windows debe entrar en la clase GUI y cambiar las lineas 90 y 132 para mejor visualización del contenido. 

registration = GUI()
registration.Start()