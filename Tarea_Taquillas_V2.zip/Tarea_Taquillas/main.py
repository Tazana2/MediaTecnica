from colas import GUI
def run():
    cosa = GUI()
    cosa.Start()

if __name__ == "__main__":
    run()